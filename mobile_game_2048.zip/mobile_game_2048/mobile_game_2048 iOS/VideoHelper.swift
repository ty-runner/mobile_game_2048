import SpriteKit
import AVFoundation

enum VideoFillMode { case aspectFit, aspectFill }

class VideoHelper {

    /// Plays a looping background video sized by aspect-fit or aspect-fill.
    /// Call from a Task: `Task { await VideoHelper.playBackgroundVideo(on: self, named: "background", fillMode: .aspectFill) }`
    @MainActor
    static func playBackgroundVideo(
        on scene: SKScene,
        named filename: String = "background",
        fillMode: VideoFillMode = .aspectFill
    ) async -> SKVideoNode? {

        guard let url = Bundle.main.url(forResource: filename, withExtension: "mp4") else {
            print("Video file not found: \(filename).mp4")
            return nil
        }

        // iOS 18: AVAsset(url:) deprecated → use AVURLAsset(url:)
        let asset = AVURLAsset(url: url)

        // Get the video’s natural size, corrected for its preferred transform (rotation, etc.)
        let videoSize: CGSize
        do {
            if #available(iOS 16.0, *) {
                let tracks = try await asset.loadTracks(withMediaType: .video)
                guard let track = tracks.first else {
                    print("No video track.")
                    return nil
                }
                let naturalSize = try await track.load(.naturalSize)
                let preferredTransform = try await track.load(.preferredTransform)
                videoSize = naturalSize.applying(preferredTransform)
            } else {
                // Legacy fallback for older iOS (sync APIs)
                guard let track = asset.tracks(withMediaType: .video).first else {
                    print("No video track.")
                    return nil
                }
                videoSize = track.naturalSize.applying(track.preferredTransform)
            }
        } catch {
            print("Failed to read video metadata: \(error)")
            return nil
        }

        let w = abs(videoSize.width)
        let h = abs(videoSize.height)
        guard w > 0, h > 0 else { return nil }

        let sceneSize = scene.size
        let sceneAspect = sceneSize.width / sceneSize.height
        let videoAspect = w / h

        // Compute final size with correct aspect
        let finalSize: CGSize = {
            switch fillMode {
            case .aspectFit:
                if videoAspect > sceneAspect {
                    // Wider than scene → match width
                    let scale = sceneSize.width / w
                    return CGSize(width: sceneSize.width, height: h * scale)
                } else {
                    // Taller/narrower → match height
                    let scale = sceneSize.height / h
                    return CGSize(width: w * scale, height: sceneSize.height)
                }
            case .aspectFill:
                if videoAspect > sceneAspect {
                    // Wider than scene → match height (crop left/right)
                    let scale = sceneSize.height / h
                    return CGSize(width: w * scale, height: sceneSize.height)
                } else {
                    // Taller/narrower → match width (crop top/bottom)
                    let scale = sceneSize.width / w
                    return CGSize(width: sceneSize.width, height: h * scale)
                }
            }
        }()

        let player = AVPlayer(url: url)
        player.isMuted = true
        player.actionAtItemEnd = .none

        let node = SKVideoNode(avPlayer: player)
        node.position = CGPoint(x: sceneSize.width / 2, y: sceneSize.height / 2)
        node.size = finalSize
        node.zPosition = -1

        scene.addChild(node)
        await player.seek(to: .zero)
        node.play()

        NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player.currentItem,
            queue: .main
        ) { _ in
            player.seek(to: .zero)
        }

        return node
    }
}
